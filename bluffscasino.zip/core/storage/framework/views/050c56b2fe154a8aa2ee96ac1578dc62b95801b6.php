
<?php $__env->startSection('panel'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card b-radius--10 ">
                <div class="card-body p-0">
                
                <div class="table-responsive--sm table-responsive">
                        <table class="table table--light style--two">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('Game Name'); ?></th>
                                <th><?php echo app('translator')->get('Minimum Invest'); ?></th>
                                <th><?php echo app('translator')->get('Maximum Invest'); ?></th>
                                <th><?php echo app('translator')->get('Status'); ?></th>
                                <th><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td data-label="<?php echo app('translator')->get('Game Name'); ?>"><?php echo e($game->name); ?></td>
                                <td data-label="<?php echo app('translator')->get('Minimum Invest'); ?>"><?php echo e($general->cur_sym); ?> <?php echo e(getAmount($game->min_limit)); ?></td>
                                <td data-label="<?php echo app('translator')->get('Maximum Invest'); ?>"><?php echo e($general->cur_sym); ?> <?php echo e(getAmount($game->max_limit)); ?></td>
                                <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                    <?php if($game->status == 0): ?>
                                    <span class="badge badge--danger"><?php echo app('translator')->get('inactive'); ?></span>
                                    <?php else: ?>
                                    <span class="badge badge--success"><?php echo app('translator')->get('active'); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                    <a href="<?php echo e(route('admin.game.'.$game->alias)); ?>" class="icon-btn"><i class="la la-pencil" data-toggle="tooltip" title="" data-original-title="Edit"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bluffscasino\core\resources\views/admin/game/index.blade.php ENDPATH**/ ?>