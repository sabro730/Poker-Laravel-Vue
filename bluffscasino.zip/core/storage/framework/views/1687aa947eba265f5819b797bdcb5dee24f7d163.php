<?php $__env->startSection('panel'); ?>
    <div class="row">
    	<div class="col-lg-6">
    		<div class="card">
                    <div class="card-header">
                        <h4 class="card-title"><?php echo app('translator')->get('CURRENT SETTING'); ?></h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table">

                                <thead>
                                <tr>
                                    <th><?php echo app('translator')->get('Chance'); ?></th>
                                    <th><?php echo app('translator')->get('Commision'); ?></th>
                                </tr>
                                </thead>
                                <tbody>

                                <?php $__currentLoopData = $bon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo app('translator')->get('CHANCE#'); ?> <?php echo e($p->chance); ?></td>
                                        <td><?php echo e(getAmount($p->percent)); ?> %</td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
    	</div>
    	<div class="col-lg-6">
    		<div class="card">
    			<div class="card-header">
    				<h4 class="card-title"><?php echo app('translator')->get('CHANCE SETTING'); ?></h4>
    			</div>

    			<div class="card-body">
    				<div class="row">
    					<div class="col-md-6">
    						<input type="number" name="level" id="levelGenerate" placeholder="<?php echo app('translator')->get('HOW MANY CHANCES'); ?>" class="form-control input-lg">
    					</div>
    					<div class="col-md-6">
    						<button type="button" id="generate" class="btn btn--success btn-block btn-md"><?php echo app('translator')->get('GENERATE'); ?></button>
    					</div>
    				</div>

    				<br>

    				<form action="<?php echo e(route('admin.game.chance.create')); ?>" method="post">
    					<?php echo e(csrf_field()); ?>

    					<div class="form-group">
    						<label class="text-success"> <?php echo app('translator')->get('Chance & Bonus'); ?> : <small>(<?php echo app('translator')->get('Old Data will Remove After Generate'); ?>)</small> </label>
    						<div class="row">
    							<div class="col-md-12">
    								<div class="description d-none">
    									<div class="row">
    										<div class="col-md-12" id="planDescriptionContainer">

    										</div>
    									</div>
    								</div>
    							</div>
    						</div>
    					</div>
    					<hr>
    					<button type="submit" class="btn btn--primary btn-block"><?php echo app('translator')->get('Submit'); ?></button>
    				</form>

    			</div>
    		</div>
    	</div>
    </div>
    <div class="row mt-5">
        <div class="col-lg-12">
        	<div class="card">
        		<form action="<?php echo e(route('admin.game.update',$game->id)); ?>" method="post" enctype="multipart/form-data">
        			<?php echo csrf_field(); ?>
        			<div class="card-body">
        				<div class="row">
        					<div class="col-md-4">
        						<div class="form-group">
        							<div class="image-upload">
        								<div class="thumb">
        									<div class="avatar-preview">
        										<div class="profilePicPreview" style="background-image: url(<?php echo e(getImage(imagePath()['game']['path'].'/'.$game->image,imagePath()['game']['size'])); ?>)">
        											<button type="button" class="remove-image"><i class="fa fa-times"></i></button>
        										</div>
        									</div>
        									<div class="avatar-edit">
        										<input type="file" class="profilePicUpload" name="image" id="profilePicUpload" accept=".png, .jpg, .jpeg" requierd>
        										<label for="profilePicUpload" class="bg--primary"><?php echo app('translator')->get('Post image'); ?></label>
        										<small class="mt-2 text-facebook"><?php echo app('translator')->get('Supported files:'); ?> <b><?php echo app('translator')->get('jpeg, jpg'); ?></b>. <?php echo app('translator')->get('Image will be resized into'); ?> <b><?php echo e(imagePath()['game']['size']); ?><?php echo app('translator')->get('px'); ?></b></small>
        									</div>
        								</div>
        							</div>
        						</div>
        					</div>
        					<div class="col-md-8">
        						<div class="row">
        							<div class="col-md-8">
        								<div class="form-group">
        									<label><?php echo app('translator')->get('Game Name'); ?></label>
        									<input type="text" name="name" class="form-control" placeholder="<?php echo app('translator')->get('Game Name'); ?>" value="<?php echo e($game->name); ?>" required>
        								</div>
        							</div>
        							<div class="col-md-4">
        								<div class="form-group">
        									<label><?php echo app('translator')->get('Status'); ?></label>
        									<div class="input-group mb-3">
        										<input type="checkbox" data-width="100%" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="Active" data-off="Inactive" name="status" <?php if($game->status == 1): ?> checked <?php endif; ?>>
        									</div>
        								</div>
        							</div>
        						</div>
                                <div class="row mt-5 justify-content-center">
                                    <div class="col-md-12">
                                        <div class="card border--primary">
                                            <h5 class="card-header bg--primary"><?php echo app('translator')->get('Play Amount'); ?></h5>
                                            <div class="card-body">
                								<div class="form-group">
                									<label><?php echo app('translator')->get('Minimum Invest Amount'); ?></label>
                									<div class="input-group mb-3">
                										<input type="text" name="min" min="1" class="form-control" placeholder="<?php echo app('translator')->get('Minimum Invest Amount'); ?>" value="<?php echo e(getAmount($game->min_limit)); ?>" required>
                										<div class="input-group-append">
                											<span class="input-group-text" id="basic-addon2"><?php echo e($general->cur_sym); ?></span>
                										</div>
                									</div>
                								</div>
                								<div class="form-group">
                									<label><?php echo app('translator')->get('Maximum Invest Amount'); ?></label>
                									<div class="input-group mb-3">
                										<input type="text" name="max" min="1" class="form-control" placeholder="<?php echo app('translator')->get('Maximum Invest Amount'); ?>" value="<?php echo e(getAmount($game->max_limit)); ?>" required>
                										<div class="input-group-append">
                											<span class="input-group-text" id="basic-addon2"><?php echo e($general->cur_sym); ?></span>
                										</div>
                									</div>
                								</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
        					</div>
        				</div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label><?php echo app('translator')->get('Game Instruction'); ?></label>
                                    <textarea rows="5" class="form-control nicEdit" name="instruction"><?php echo $game->instruction ?></textarea>
                                </div>
                            </div>
                        </div>
        			</div>
        			<div class="card-footer">
        				<button type="submit" class="btn btn--success btn-lg btn-block"><?php echo app('translator')->get('Update'); ?></button>
        			</div>
        		</form>
        	</div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('style'); ?>
<style type="text/css">
    .description{
        width: 100%;
        border: 1px solid #ddd;
        padding: 10px;
        border-radius: 5px
    }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        (function($){
            "use strict";
            var max = 1;
            $(document).ready(function () {
                $("#generate").on('click', function () {
                    var da = $('#levelGenerate').val();
                    var a = 0;
                    var val = 1;
                    var data = '';
                    if (da !== '' && da >0)
                    {
                        $('.description').removeClass('d-none')

                        for (a; a < parseInt(da);a++){

                            data += '<div class="input-group" style="margin-top: 5px">\n' +
                                '<input name="chance[]" class="form-control margin-top-10" type="number" readonly value="'+val+++'" required placeholder="Level">\n' +
                                '<input name="percent[]" class="form-control margin-top-10" type="text" required placeholder="Commission Percentage %">\n' +
                                '<span class="input-group-btn">\n' +
                                '<button class="btn btn-danger margin-top-10 delete_desc" type="button"><i class=\'fa fa-times\'></i></button></span>\n' +
                                '</div>'
                        }
                        $()
                        $('#planDescriptionContainer').html(data);

                    }else {
                        alert('Chance Field Is Required')
                    }

                });

                $(document).on('click', '.delete_desc', function () {
                    $(this).closest('.input-group').remove();
                });
            });
        })(jQuery)

    </script>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('breadcrumb-plugins'); ?>
<a href="<?php echo e(route('admin.game.index')); ?>" class="icon-btn"><i class="fa fa-fw fa-backward"></i> <?php echo app('translator')->get('Go Back'); ?> </a>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bluffscasino\core\resources\views/admin/game/guessing.blade.php ENDPATH**/ ?>