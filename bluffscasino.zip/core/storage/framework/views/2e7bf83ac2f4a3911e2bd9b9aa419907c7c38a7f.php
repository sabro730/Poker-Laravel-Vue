<?php $__env->startSection('content'); ?>
    <div class="container pt-120 pb-120">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header text-center"><?php echo app('translator')->get('Please Verify Your Email to Get Access'); ?></div>

                    <div class="card-body">

                        <form action="<?php echo e(route('user.verify.email')); ?>" method="POST" class="login-form">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <p class="text-center"><?php echo app('translator')->get('Your Email'); ?>: <strong><?php echo e(auth()->user()->email); ?></strong>
                                </p>
                            </div>


                            <div class="form-group">
                                <label class=""><?php echo app('translator')->get('Verification Code'); ?></label>
                                <input type="text" name="email_verified_code" class="form-control" maxlength="7"
                                       id="code">
                            </div>


                            <div class="form-group">
                                <div class="btn-area text-center">
                                    <button type="submit" class="cmn-btn"><?php echo app('translator')->get('Submit'); ?></button>
                                </div>
                            </div>


                            <div class="form-group">
                                <p><?php echo app('translator')->get('Please check including your Junk/Spam Folder. if not found, you can'); ?> <a
                                        href="<?php echo e(route('user.send.verify.code')); ?>?type=email"
                                        class="forget-pass"> <?php echo app('translator')->get('Resend code'); ?></a></p>
                                <?php if($errors->has('resend')): ?>
                                    <br/>
                                    <small class="text-danger"><?php echo e($errors->first('resend')); ?></small>
                                <?php endif; ?>
                            </div>


                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        (function ($) {
            "use strict";
            $('#code').on('input change', function () {
                var xx = document.getElementById('code').value;
                
                $(this).val(function (index, value) {
                    value = value.substr(0, 7);
                    return value.replace(/\W/gi, '').replace(/(.{3})/g, '$1 ');
                });

            });
        })(jQuery)
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate .'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bluffscasino\core\resources\views/templates/basic/user/auth/authorization/email.blade.php ENDPATH**/ ?>