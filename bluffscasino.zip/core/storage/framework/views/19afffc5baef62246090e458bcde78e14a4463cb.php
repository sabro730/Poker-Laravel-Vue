<?php echo  loadTawkto() ?>
<?php echo  loadAnalytics() ?><?php /**PATH C:\xampp\htdocs\bluffscasino\core\resources\views/partials/plugins.blade.php ENDPATH**/ ?>