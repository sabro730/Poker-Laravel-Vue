<?php $__env->startSection('panel'); ?>
    <div class="row">
        <div class="col-lg-12">
        	<div class="card">
        		<form action="<?php echo e(route('admin.game.update',$game->id)); ?>" method="post" enctype="multipart/form-data">
        			<?php echo csrf_field(); ?>
        			<div class="card-body">
        				<div class="row">
	        				<div class="col-md-4">
		        				<div class="form-group">
		        					<div class="image-upload">
		        						<div class="thumb">
		        							<div class="avatar-preview">
		        								<div class="profilePicPreview" style="background-image: url(<?php echo e(getImage(imagePath()['game']['path'].'/'.$game->image,imagePath()['game']['size'])); ?>)">
		        									<button type="button" class="remove-image"><i class="fa fa-times"></i></button>
		        								</div>
		        							</div>
		        							<div class="avatar-edit">
		        								<input type="file" class="profilePicUpload" name="image" id="profilePicUpload" accept=".png, .jpg, .jpeg" requierd>
		        								<label for="profilePicUpload" class="bg--primary"><?php echo app('translator')->get('Post image'); ?></label>
		        								<small class="mt-2 text-facebook"><?php echo app('translator')->get('Supported files:'); ?> <b><?php echo app('translator')->get('jpeg, jpg'); ?></b>. <?php echo app('translator')->get('Image will be resized into'); ?> <b><?php echo e(imagePath()['game']['size']); ?><?php echo app('translator')->get('px'); ?></b></small>
		        							</div>
		        						</div>
		        					</div>
		        				</div>
	        				</div>
	        				<div class="col-md-8">
	        					<div class="row">
	        						<div class="col-md-8">
	        							<div class="form-group">
	        								<label><?php echo app('translator')->get('Game Name'); ?></label>
	        								<input type="text" name="name" class="form-control" placeholder="<?php echo app('translator')->get('Game Name'); ?>" value="<?php echo e($game->name); ?>" required>
	        							</div>
	        						</div>
	        						<div class="col-md-4">
	        							<div class="form-group">
	        								<label><?php echo app('translator')->get('Status'); ?></label>
	        								<div class="input-group mb-3">
	        									<input type="checkbox" data-width="100%" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="Active" data-off="Inactive" name="status" <?php if($game->status == 1): ?> checked <?php endif; ?>>
	        								</div>
	        							</div>
	        						</div>
	        					</div>
	        					<div class="row mt-5">
									<div class="col-md-5">
										<div class="card border--primary">
											<h5 class="card-header bg--primary"><?php echo app('translator')->get('Play Amount'); ?></h5>
											<div class="card-body">
			        							<div class="form-group">
			        								<label><?php echo app('translator')->get('Minimum Invest Amount'); ?></label>
			        								<div class="input-group mb-3">
			        									<input type="text" name="min" min="1" class="form-control" placeholder="<?php echo app('translator')->get('Minimum Invest Amount'); ?>" value="<?php echo e(getAmount($game->min_limit)); ?>" required>
			        									<div class="input-group-append">
			        										<span class="input-group-text" id="basic-addon2"><?php echo e($general->cur_sym); ?></span>
			        									</div>
			        								</div>
			        							</div>
			        							<div class="form-group">
			        								<label><?php echo app('translator')->get('Maximum Invest Amount'); ?></label>
			        								<div class="input-group mb-3">
			        									<input type="text" name="max" min="1" class="form-control" placeholder="<?php echo app('translator')->get('Maximum Invest Amount'); ?>" value="<?php echo e(getAmount($game->max_limit)); ?>" required>
			        									<div class="input-group-append">
			        										<span class="input-group-text" id="basic-addon2"><?php echo e($general->cur_sym); ?></span>
			        									</div>
			        								</div>
			        							</div>
											</div>
										</div>
									</div>
									<div class="col-md-7">
										<div class="card border--warning">
											<h5 class="card-header bg--warning"><?php echo app('translator')->get('Win Setting'); ?> </h5>
											<div class="card-body">
												<div class="row">
													<div class="col-md-12">
					        							<div class="form-group">
					        								<label><?php echo app('translator')->get('Winning Chance'); ?></label>
					        								<div class="input-group mb-3">
					        									<input type="number" class="form-control" name="probable" value="<?php echo e(getAmount($game->probable_win)); ?>" placeholder="<?php echo app('translator')->get('Winning Chance'); ?>">
					        									<div class="input-group-append">
					        										<span class="input-group-text" id="basic-addon2"><?php echo app('translator')->get('%'); ?></span>
					        									</div>
					        								</div>
					        							</div>
													</div>
													<div class="col-md-6">
					        							<div class="form-group">
					        								<label><?php echo app('translator')->get('Win Amount'); ?></label>
					        								<div class="input-group mb-3">
					        									<input type="text" class="form-control" placeholder="<?php echo app('translator')->get('Win'); ?>" value="<?php echo e(getAmount($game->win)); ?>" name="win">
					        									<div class="input-group-append">
					        										<span class="input-group-text" id="basic-addon2"><?php echo app('translator')->get('%'); ?></span>
					        									</div>
					        								</div>
					        							</div>
													</div>
													<div class="col-md-6">
														<div class="form-group">
					        								<label><?php echo app('translator')->get('Invest'); ?></label>
					        								<div class="input-group mb-3">
					        									<input type="checkbox" data-width="100%" data-onstyle="-success" data-offstyle="-danger" data-toggle="toggle" data-on="<?php echo app('translator')->get('Give Back'); ?>" data-off="<?php echo app('translator')->get('No Back'); ?>" name="invest_back" <?php if($game->invest_back == 1): ?> checked <?php endif; ?>>
					        								</div>
					        							</div>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
	        				</div>
	        			</div>
	        			<div class="row">
	        				<div class="col-md-12">
	        					<div class="form-group">
	        						<label><?php echo app('translator')->get('Game Instruction'); ?></label>
	        						<textarea rows="5" class="form-control nicEdit" name="instruction"><?php echo $game->instruction ?></textarea>
	        					</div>
	        				</div>
	        			</div>
        			</div>
        			<div class="card-footer">
        				<button type="submit" class="btn btn--success btn-lg btn-block"><?php echo app('translator')->get('Update'); ?></button>
        			</div>
        		</form>
        	</div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('breadcrumb-plugins'); ?>
<a href="<?php echo e(route('admin.game.index')); ?>" class="icon-btn"><i class="la la-fw la-backward"></i> <?php echo app('translator')->get('Go Back'); ?> </a>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\bluffscasino\core\resources\views/admin/game/cardFinding.blade.php ENDPATH**/ ?>