<?php
    $statisticsContent = getContent('statistics.content',true);
    $statisticsElements = getContent('statistics.element');
?>
<!-- statistics section start -->
<section class="statistics-section  section--bg">
    <div class="shape-1"></div>
    <div class="shape-2"></div>
    <div class="container">
        <div class="row mb-none-30">
            <?php $__currentLoopData = $statisticsElements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statisticsElement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 col-6 mb-30">
                    <div class="stat-card">
                        <div class="stat-card__icon wow fadeInLeft" data-wow-duration="0.5s" data-wow-delay="0.3s">
                            <?php echo $statisticsElement->data_values->icon ?>
                        </div>
                        <div class="stat-card__content wow fadeInRight" data-wow-duration="0.5s" data-wow-delay="0.5s">
                            <h6 class="title"><?php echo e(__($statisticsElement->data_values->title)); ?></h6>
                            <span class="numbers"><?php echo e(__($statisticsElement->data_values->amount)); ?></span>
                        </div>
                    </div>
                    <!-- stat-card end -->
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!-- statistics section end -->
<?php /**PATH C:\xampp\htdocs\bluffscasino\core\resources\views/templates/basic/sections/statistics.blade.php ENDPATH**/ ?>