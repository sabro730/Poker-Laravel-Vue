<?php
	$captcha = loadCustomCaptcha();
?>
<?php if($captcha): ?>
    <div class="form-group col-md-6">
        <?php echo $captcha ?>
    </div>
    <div class="form-group col-md-6">
        <input type="text" name="captcha" placeholder="<?php echo app('translator')->get('Enter Code'); ?>" class="form-control" required>
    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\bluffscasino\core\resources\views/templates/basic/partials/custom_captcha.blade.php ENDPATH**/ ?>