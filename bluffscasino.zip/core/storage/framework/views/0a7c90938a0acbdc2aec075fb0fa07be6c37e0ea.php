<?php $__env->startSection('content'); ?>
   <?php
      $banner = getContent('banner.content',true);
   ?>

      <!-- hero start -->
      <section class="hero bg_img" style="background-image: url( <?php echo e(getImage('assets/images/frontend/banner/'.@$banner->data_values->image,'1920x780')); ?> );">
         <div class="container">
            <div class="row justify-content-between align-items-center">
               <div class="col-lg-6">
                  <div class="hero__content text-lg-left text-center">
                     <h2 class="hero__title wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.3s"><?php echo e(__($banner->data_values->heading)); ?></h2>
                     <p class="wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.5s"><?php echo e(__($banner->data_values->sub_heading)); ?></p>
                     <div class="btn-group justify-content-lg-start justify-content-center mt-4 wow fadeInUp" data-wow-duration="0.5s" data-wow-delay="0.9s">
                        <a href="<?php echo e(__($banner->data_values->button_url_1)); ?>" class="cmn-btn"><?php echo e(__($banner->data_values->button_1)); ?></a>
                        <a href="<?php echo e(__($banner->data_values->button_url_2)); ?>" class="cmn-btn-two"><?php echo e(__($banner->data_values->button_2)); ?></a>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- hero end -->

    <?php if($sections->secs != null): ?>
        <?php $__currentLoopData = json_decode($sections->secs); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make($activeTemplate.'sections.'.$sec, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\bluffscasino\core\resources\views/templates/basic/home.blade.php ENDPATH**/ ?>