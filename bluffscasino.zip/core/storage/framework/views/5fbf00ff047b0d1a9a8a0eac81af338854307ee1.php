<!-- <?php
    $methodContent = getContent('payment_method.content',true);
    $methodElements = getContent('payment_method.element');
?> -->
<!-- payment method section start -->
<!-- <section class="pb-120">
    
</section> -->
<!-- payment method section end -->
<?php /**PATH /home/n4oie36cs255/public_html/core/resources/views/templates/basic/sections/payment_method.blade.php ENDPATH**/ ?>