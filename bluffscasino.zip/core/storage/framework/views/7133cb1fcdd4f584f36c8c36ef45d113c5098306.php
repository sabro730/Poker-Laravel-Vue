<?php $__env->startSection('panel'); ?>
    <div class="row">

        <div class="col-lg-12">
            <div class="card b-radius--10 ">
                <div class="card-body p-0">

                    <div class="table-responsive--sm table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                            <tr>
                                <th class="text-center"><?php echo app('translator')->get('Game Name'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Username'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('User Select'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Result'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Invest'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Win or fail'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td data-label="<?php echo app('translator')->get('Game Name'); ?>"
                                        class="text-center"><?php echo e(__($log->game->name)); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Username'); ?>" class="text-center">
                                        <a href="<?php echo e(route('admin.users.detail', $log->user->id)); ?>"> <?php echo e($log->user->username); ?></a>
                                    </td>
                                    <td data-label="<?php echo app('translator')->get('User Select'); ?>" class="text-center">
                                        <?php if(gettype(json_decode($log->user_select)) == 'array'): ?>
                                            <?php $__currentLoopData = json_decode($log->user_select); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choose): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e(__($choose)); ?><?php if($loop->last): ?> <?php else: ?> , <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <?php echo e(__($log->user_select)); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Result'); ?>" class="text-center">
                                        <?php if(gettype(json_decode($log->result)) == 'array'): ?>
                                            <?php $__currentLoopData = json_decode($log->result); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e(__($result)); ?><?php if($loop->last): ?> <?php else: ?> , <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <?php echo e(__($log->result)); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Invest'); ?>"
                                        class="text-center"><?php echo e($general->cur_sym); ?> <?php echo e(__(getAmount($log->invest))); ?> </td>
                                    <td data-label="<?php echo app('translator')->get('Win or fail'); ?>" class="text-center">
                                        <?php if($log->win_status != 0): ?>
                                            <spin class="badge badge--success"><?php echo app('translator')->get('Win'); ?></spin>
                                        <?php else: ?>
                                            <spin class="badge badge--danger"><?php echo app('translator')->get('Lost'); ?></spin>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="100%" class="text-center"><?php echo app('translator')->get('No Data Found'); ?></td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="card-footer py-4">
                    <?php echo e($logs->links('admin.partials.paginate')); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/n4oie36cs255/public_html/core/resources/views/admin/game/gameLog.blade.php ENDPATH**/ ?>