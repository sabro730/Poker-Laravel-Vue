<!-- <?php
    $methodContent = getContent('payment_method.content',true);
    $methodElements = getContent('payment_method.element');
?> -->
<!-- payment method section start -->
<!-- <section class="pb-120">
    
</section> -->
<!-- payment method section end -->
<?php /**PATH C:\bluffscasino\core\resources\views/templates/basic/sections/payment_method.blade.php ENDPATH**/ ?>